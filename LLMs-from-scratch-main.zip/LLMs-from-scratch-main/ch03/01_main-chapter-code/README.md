# Chapter 3: Coding Attention Mechanisms

### Main Chapter Code

- [ch03.ipynb](ch03.ipynb) contains all the code as it appears in the chapter

### Optional Code

- [multihead-attention.ipynb](multihead-attention.ipynb) is a minimal notebook with the main data loading pipeline implemented in this chapter

