# Chapter 1: Understanding Large Language Models


&nbsp;
## Main Chapter Code

There is no code in this chapter.


&nbsp;
## Bonus Materials

As optional bonus material, below is a video tutorial where I explain the LLM development lifecycle covered in this book:

<br>
<br>

[![Link to the video](https://img.youtube.com/vi/kPGTx4wcm_w/0.jpg)](https://www.youtube.com/watch?v=kPGTx4wcm_w)

